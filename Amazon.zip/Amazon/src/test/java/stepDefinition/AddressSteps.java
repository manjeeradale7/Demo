package stepDefinition;

import hooks.AmazonHooks;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import pages.AddressPage;
import pages.LoginPages;

public class AddressSteps {
     WebDriver driver = AmazonHooks.driver;
    LoginPages loginPage = new LoginPages(driver);
    AddressPage addressPage = new AddressPage(driver);

    @Given("User logs into Amazon")
    public void user_logs_into_amazon() {
        loginPage.openAmazonPages();
        loginPage.clickSignInLink();
        loginPage.enterEmail("hemadasari2003@gmail.com");
        loginPage.enterPassword("Hema@123");
    }

    @Given("User navigates to the address page")
    public void user_navigates_to_the_address_page() {
        addressPage.openAddressPage();
    }

    @When("User leaves mandatory fields empty")
    public void user_leaves_mandatory_fields_empty() {
        addressPage.clickAddAddress();
        addressPage.saveAddress();
        
    }@Then("Error messages should be displayed for mandatory fields")
    public void error_messages_should_be_displayed_for_mandatory_fields() {
        try {
            // Wait for error to appear
            String errorMsg = addressPage.waitForErrorMessage();
            System.out.println("Error message is displayed: " + errorMsg);
            org.testng.Assert.assertTrue(errorMsg.length() > 0, "Error message is empty!");
        } catch (Exception e) {
            org.testng.Assert.fail("Mandatory field errors not displayed!");
        }
    }

    @When("User adds a new address with valid details")
    public void user_adds_a_new_address_with_valid_details() {
    	 addressPage.openAddressPage();
        addressPage.clickAddAddress();
        addressPage.enterAddressDetails("Hema ", "9666462953", "522201",
                "1-39-30, puttavari street", "Tenali");
        addressPage.saveAddress();
    }

    @Then("The new address should be saved successfully")
    public void the_new_address_should_be_saved_successfully() {
        System.out.println("Address added successfully.");
    }

    @When("User edits the existing address")
    public void user_edits_the_existing_address() {
    	
    	addressPage.editAddress("9493801752");
        System.out.println("Address edited successfully.");
    }

    @When("User deletes the address")
    public void user_deletes_the_address() {
        addressPage.deleteAddress();
        System.out.println("Address deleted successfully.");
    }

    @Then("The address should be removed from the address list")
    public void the_address_should_be_removed_from_the_address_list() {
        System.out.println("Address removal verified.");
    }
}