package stepDefinition;

import hooks.AmazonHooks;
import io.cucumber.java.en.*;
import pages.RegistrationPage;

public class RegistrationSteps {
    RegistrationPage registrationPage = new RegistrationPage(AmazonHooks.driver);

    @Given("User is on the Amazon registration page")
    public void user_is_on_registration_page() {
        AmazonHooks.driver.get("https://www.amazon.in/register");
    }

    @When("User selects country code {string}")
    public void user_selects_country_code(String countryCode) {
        registrationPage.selectCountryCode(countryCode);
    }

    @When("User enters full name {string}")
    public void user_enters_full_name(String name) {
        registrationPage.enterFullName(name);
    }

    @When("User enters mobile number {string}")
    public void user_enters_mobile_number(String mobile) {
        registrationPage.enterMobileNumber(mobile);
    }

    @When("User enters password {string}")
    public void user_enters_password(String password) {
        registrationPage.enterPassword(password);
    }

    @When("Clicks on Verify mobile number")
    public void clicks_on_verify_mobile_number() {
        registrationPage.clickVerifyMobile();
    }

    @When("Clicks on Create Amazon account button")
    public void clicks_on_create_amazon_account_button() {
        registrationPage.clickCreateAccount();
    }

    @Then("Amazon account creation should be initiated")
    public void amazon_account_creation_should_be_initiated() {
        System.out.println("Amazon account creation flow started (OTP page will appear).");
    }
}