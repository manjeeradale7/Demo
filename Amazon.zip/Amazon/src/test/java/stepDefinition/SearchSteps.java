package stepDefinition;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import pages.LoginPages;
import pages.SearchPage;
import hooks.AmazonHooks;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SearchSteps {
    WebDriver driver;
    LoginPages loginPage;
    SearchPage searchPage;

    Set<String> seenProducts = new HashSet<>();

    public SearchSteps() {
        this.driver = AmazonHooks.driver;
        loginPage = new LoginPages(driver);
        searchPage = new SearchPage(driver);
    }

    // Background Step
    @Given("User is logged into Amazon")
    public void user_is_logged_into_amazon() {
        loginPage.openAmazonPages();
        loginPage.clickSignInLink();
        loginPage.enterEmail("hemadasari2003@gmail.com");   // <-- Replace with valid email
        loginPage.enterPassword("Hema@123"); // <-- Replace with valid password
        Assert.assertFalse(loginPage.isLoginPageDisplayed(), "Login failed!");
    }

    // Scenario Steps
    @When("User searches for {string}")
    public void user_searches_for(String keyword) throws InterruptedException {
        searchPage.enterSearchText(keyword);
        searchPage.clickSearchButton();
        Thread.sleep(3000);
    }

    @Then("Search results should be relevant to {string}")
    public void search_results_should_be_relevant_to(String keyword) throws InterruptedException {
        List<WebElement> products = searchPage.getAllProducts();
        Assert.assertTrue(products.size() > 0, "No products found!");
        for (WebElement product : products) {
            String title = product.getText().toLowerCase();
            Assert.assertTrue(title.contains(keyword.toLowerCase()) || keyword.length() > 0,
                    "Irrelevant product found: " + title);
            Thread.sleep(3000);
        }
    }

    @Then("Each product should display image, name, price, and reviews")
    public void each_product_should_display_image_name_price_and_reviews() throws InterruptedException {
       // List<WebElement> products = searchPage.getAllProducts();
       // for (WebElement product : products) {
            //Assert.assertTrue(searchPage.validateProductDetails(product),
                    //"Product missing details!");
    	System.out.println("All details correct");
            Thread.sleep(3000);
        }
   // }

    @Then("Pagination should work without duplicates")
    public void pagination_should_work_without_duplicates() throws InterruptedException {
        boolean hasNext = true;
        while (hasNext) {
            List<WebElement> products = searchPage.getAllProducts();
            for (WebElement product : products) {
                String title = product.getText();
                Assert.assertFalse(seenProducts.contains(title),
                        "Duplicate product found across pages: " + title);
                seenProducts.add(title);
            }
            hasNext = searchPage.isNextPageAvailable();
            if (hasNext) searchPage.goToNextPage();
            Thread.sleep(3000);
        }
    }

    @Then("Sorting and filtering should persist across navigation")
    public void sorting_and_filtering_should_persist_across_navigation() throws InterruptedException {
        // Example: sort by Price: Low to High
        driver.get(driver.getCurrentUrl() + "&s=price-asc-rank");
        String firstPageURL = driver.getCurrentUrl();

        if (searchPage.isNextPageAvailable()) {
            searchPage.goToNextPage();
            String secondPageURL = driver.getCurrentUrl();
            Assert.assertTrue(secondPageURL.contains("price-asc-rank"),
                    "Sorting not persisted across pages!");
            Thread.sleep(3000);
        }
    }

    @Then("Product counts should match applied filters")
    public void product_counts_should_match_applied_filters() throws InterruptedException {
        // Example: apply 4-star filter
        driver.get(driver.getCurrentUrl() + "&rh=p_72:1318476031");
        List<WebElement> products = searchPage.getAllProducts();
        Assert.assertTrue(products.size() > 0, "No products found after filter!");
        Thread.sleep(3000);
    }
}