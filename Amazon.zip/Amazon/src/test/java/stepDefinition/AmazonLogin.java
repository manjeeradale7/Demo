
package stepDefinition;

import hooks.AmazonHooks;
import io.cucumber.java.en.*;
import pages.AmazonPages;

public class AmazonLogin {
    AmazonPages loginPage;

    @Given("User launches Amazon homepage")
    public void user_launches_amazon_homepage() {
        AmazonHooks.driver.get("https://www.amazon.in/");
        loginPage = new AmazonPages(AmazonHooks.driver);
    }

    @When("User clicks on Sign In link")
    public void user_clicks_on_sign_in_link() {
        loginPage.clickSignInLink();
    }

    @When("User enters username {string} and password {string}")
    public void user_enters_username_and_password(String user, String pass) {
        loginPage.enterEmail(user);
        loginPage.enterPassword(pass);
    }

    @When("User clicks on login button")
    public void user_clicks_on_login_button() {
        loginPage.clickLogin();
    }

    @When("User navigates to {string}")
    public void user_navigates_to(String page) {
        if (page.equalsIgnoreCase("Cart")) {
            loginPage.navigateToCart();
        } else if (page.equalsIgnoreCase("Orders")) {
            loginPage.navigateToOrders();
        }
    }

    @Then("User session should still be active")
    public void user_session_should_still_be_active() {
        if (loginPage.isSessionActive()) {
            System.out.println("Session is active.");
        } else {
            throw new RuntimeException("Session expired!");
        }
    }

    @Then("Error message should be displayed")
    public void error_message_should_be_displayed() {
        if (loginPage.isErrorMessageDisplayed()) {
            System.out.println("Error message displayed.");
        } 
    }

    @When("User logs out")
    public void user_logs_out() {
        loginPage.logout();
    }

    @Then("User should be redirected to login page")
    public void user_should_be_redirected_to_login_page() {
        if (loginPage.isLoginPageDisplayed()) {
            System.out.println("Redirected to login page.");
        } 
    }

    @When("User remains inactive for {string} seconds")
    public void user_remains_inactive(String seconds) throws InterruptedException {
        Thread.sleep(Integer.parseInt(seconds) * 1000);
    }

    @Then("User session should expire")
    public void user_session_should_expire() {
        if (!loginPage.isSessionActive()) {
            System.out.println("Session expired.");
        } 
    }
}