package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class SearchPage {
    WebDriver driver;

    // Locators
    private By searchBox = By.id("twotabsearchtextbox");
    private By searchButton = By.id("nav-search-submit-button");
    private By productList = By.cssSelector("div.s-main-slot div[data-component-type='s-search-result']");
    private By productTitle = By.cssSelector("h2 a span");
    private By productImage = By.cssSelector("img.s-image");
    private By productPrice = By.cssSelector("span.a-price-whole");
    private By productReviews = By.cssSelector("span.a-size-base");
    private By paginationNext = By.cssSelector("a.s-pagination-next");

    public SearchPage(WebDriver driver) {
        this.driver = driver;
    }

    // Enter search text
    public void enterSearchText(String keyword) {
        driver.findElement(searchBox).clear();
        driver.findElement(searchBox).sendKeys(keyword);
    }

    // Click search button
    public void clickSearchButton() {
        driver.findElement(searchButton).click();
    }

    // Get all product containers
    public List<WebElement> getAllProducts() {
        return driver.findElements(productList);
    }

    // Validate product details (title, image, price, reviews)
    public boolean validateProductDetails(WebElement product) {
        try {
            product.findElement(productTitle).isDisplayed();
            product.findElement(productImage).isDisplayed();
            product.findElement(productPrice).isDisplayed();
            product.findElement(productReviews).isDisplayed();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // Pagination
    public boolean isNextPageAvailable() {
        return driver.findElements(paginationNext).size() > 0;
    }

    public void goToNextPage() {
        driver.findElement(paginationNext).click();
    }
}