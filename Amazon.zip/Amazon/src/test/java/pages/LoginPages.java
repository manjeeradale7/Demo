package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPages {
    WebDriver driver;

    // Locators
    By signInLink = By.id("nav-link-accountList");
    By emailField = By.id("ap_email_login");
    By continueBtn = By.id("continue");
    By passwordField = By.id("ap_password");
    By loginBtn = By.id("signInSubmit");
    By loginPageIdentifier = By.id("ap_email");

    public LoginPages(WebDriver driver) {
        this.driver = driver;
    }

    public void openAmazonPages() {
        driver.get("https://www.amazon.in/");
    }

    public void clickSignInLink() {
        driver.findElement(signInLink).click();
    }

    public void enterEmail(String email) {
        driver.findElement(emailField).sendKeys(email);
        driver.findElement(continueBtn).click();
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).sendKeys(password);
        driver.findElement(loginBtn).click();
    }

    public boolean isLoginPageDisplayed() {
        try {
            return driver.findElement(loginPageIdentifier).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}