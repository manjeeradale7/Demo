package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class AddressPage {
    WebDriver driver;
    WebDriverWait wait;

    // Locators
    By addAddressBtn = By.id("ya-myab-plus-address-icon");
    By fullName = By.id("address-ui-widgets-enterAddressFullName");
    By mobileNumber = By.id("address-ui-widgets-enterAddressPhoneNumber");
    By postalCode = By.id("address-ui-widgets-enterAddressPostalCode");
    By addressLine1 = By.id("address-ui-widgets-enterAddressLine1");
    By city = By.id("address-ui-widgets-enterAddressCity");
    By saveBtn = By.xpath("//input[@aria-labelledby='address-ui-widgets-form-submit-button-announce']");
    By errorMessage = By.cssSelector("div.a-alert-content");
    By updateBtn = By.xpath("//*[@id=\'address-ui-widgets-form-submit-button\']/span/input");
    By editAddressBtn = By.id("ya-myab-address-edit-btn-0");
    By deleteAddressBtn = By.id("ya-myab-address-delete-btn-2");
    By confirmDeleteBtn = By.xpath("//*[@id=\"deleteAddressModal-2-submit-btn\"]/span/input"); 

    public AddressPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void openAddressPage() {
    	driver.get("https://www.amazon.in/a/addresses?ref_=ya_d_c_addr");    
    }

    public void clickAddAddress() {
        wait.until(ExpectedConditions.elementToBeClickable(addAddressBtn)).click();
    }

    public void saveAddress() {
        wait.until(ExpectedConditions.elementToBeClickable(saveBtn)).click();
    }

    public void enterAddressDetails(String name, String mobile, String pincode, String addressLine, String cityName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(fullName)).clear();
        driver.findElement(fullName).sendKeys(name);
        driver.findElement(mobileNumber).clear();
        driver.findElement(mobileNumber).sendKeys(mobile);
        driver.findElement(postalCode).clear();
        driver.findElement(postalCode).sendKeys(pincode);
        driver.findElement(addressLine1).clear();
        driver.findElement(addressLine1).sendKeys(addressLine);
        driver.findElement(city).clear();
        driver.findElement(city).sendKeys(cityName);
    }

    public boolean isErrorDisplayed() {
        try {
            return driver.findElement(errorMessage).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public String getErrorText() {
        try {
            return driver.findElement(By.cssSelector("div.a-alert-content")).getText();
        } catch (Exception e) {
            return "No error message found!";
        }
    }
    
    public String waitForErrorMessage() {
        try {
            return wait.until(ExpectedConditions
                    .visibilityOfElementLocated(errorMessage))
                    .getText();
        } catch (Exception e) {
            return "No error message found!";
        }
    }


    public void editAddress(String updatedNumber) {
        wait.until(ExpectedConditions.elementToBeClickable(editAddressBtn)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(mobileNumber)).clear();
        driver.findElement(mobileNumber).sendKeys(updatedNumber);
        wait.until(ExpectedConditions.elementToBeClickable(updateBtn)).click();
    }

    public void deleteAddress() {
        wait.until(ExpectedConditions.elementToBeClickable(deleteAddressBtn)).click();
        wait.until(ExpectedConditions.elementToBeClickable(confirmDeleteBtn)).click();
    }
    
}