package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AmazonPages {
    WebDriver driver;

    // Locators
    By signInLink = By.id("nav-link-accountList");
    By emailField = By.id("ap_email_login");
    By continueBtn = By.id("continue");
    By passwordField = By.id("ap_password");
    By loginBtn = By.id("signInSubmit");
    By errorMessage = By.cssSelector("div.a-alert-content");
    By cartLink = By.id("nav-cart");
    By ordersLink = By.id("nav-orders");
    By accountList = By.xpath("//*[@id=\"nav-link-accountList\"]/button");
    By signOutLink = By.className("nav-text");
    By loginPageIdentifier = By.id("ap_email");

    public AmazonPages(WebDriver driver) {
        this.driver = driver;
    }

    public void clickSignInLink() {
        driver.findElement(signInLink).click();
    }

    public void enterEmail(String email) {
        driver.findElement(emailField).sendKeys(email);
        driver.findElement(continueBtn).click();
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).sendKeys(password);
    }

    public void clickLogin() {
        driver.findElement(loginBtn).click();
    }

    public boolean isErrorMessageDisplayed() {
        try {
            return driver.findElement(errorMessage).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void navigateToCart() {
        driver.findElement(cartLink).click();
    }

    public void navigateToOrders() {
        driver.findElement(ordersLink).click();
    }

    public boolean isSessionActive() {
        try {
            return driver.findElement(accountList).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public void logout() {
        driver.findElement(accountList).click();
        driver.findElement(signOutLink).click();
    }

    public boolean isLoginPageDisplayed() {
        try {
            return driver.findElement(loginPageIdentifier).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

	
}