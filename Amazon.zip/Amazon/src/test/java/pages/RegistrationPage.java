package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPage {
    WebDriver driver;

    // Locators
    private By countryCodeDropdown = By.id("auth-country-picker");  
    private By fullNameField = By.id("ap_customer_name");
    private By mobileNumberField = By.id("ap_phone_number");
    private By passwordField = By.id("ap_password");
    private By verifyMobileBtn = By.id("continue");   
    private By createAccountBtn = By.id("auth-continue"); 

   
    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
    }
    public void selectCountryCode(String countryCodeText) {
        Select select = new Select(driver.findElement(countryCodeDropdown));
        select.selectByVisibleText(countryCodeText);
    }

    public void enterFullName(String fullName) {
        driver.findElement(fullNameField).sendKeys(fullName);
    }

    public void enterMobileNumber(String mobile) {
        driver.findElement(mobileNumberField).sendKeys(mobile);
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).sendKeys(password);
    }

    public void clickVerifyMobile() {
        driver.findElement(verifyMobileBtn).click();
    }

    public void clickCreateAccount() {
        driver.findElement(createAccountBtn).click();
    }
}